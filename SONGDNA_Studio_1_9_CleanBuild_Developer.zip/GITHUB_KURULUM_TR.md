# SONGDNA Studio 1.8 — GitHub yükleme kılavuzu

1. `SONGDNA_Studio_1_8_CleanBuild_Developer.zip` dosyasını indirip çıkartın.
2. Çıkan klasörün içine girin.
3. İçindeki `.github`, `android-wrapper`, `backend`, `www`, `scripts` klasörlerini ve README dosyalarını GitHub deposunun ana dizinine yükleyin.
4. Dosya yöneticiniz `.github` klasörünü gizliyorsa gizli dosyaları gösterin.
5. GitHub'da Actions sekmesine geçin.
6. `SONGDNA Studio 1.8 - Android APK` iş akışını seçin.
7. `Run workflow` ile başlatın.
8. Yeşil tik oluşunca çalıştırmaya girin ve `SONGDNA-Studio-1.8-debug-APK` artifact'ini indirin.
9. Artifact ZIP'ini çıkartıp `app-debug.apk` dosyasını telefona kurun.

**Elle YAML yazmayın.** Paket içindeki `.github/workflows/build-apk.yml` dosyası hazırdır.

**Yanlış depoyu çalıştırmayın.** Yeni workflow yalnızca bu dosyaları yüklediğiniz depoda görünür. Eski `SongGEN` veya başka bir deponun geçmiş çalıştırmaları bu paketin sonucu değildir.

Kırmızı hata oluşursa Actions çalıştırmasını açıp kırmızı işin içindeki son hata mesajını paylaşın; dosyaları yeniden yükleyip baştan denemek yerine gerçek hata satırını düzelteceğiz.
