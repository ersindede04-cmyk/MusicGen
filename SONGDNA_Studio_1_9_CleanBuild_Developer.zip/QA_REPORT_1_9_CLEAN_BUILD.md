# SONGDNA Studio 1.9 — Clean Build QA Report

## Source basis
- Application/UI and Intro DNA: supplied SONGDNA Studio 1.7 IntroDNA Expanded source.
- Backend/security and AI integration: compared against supplied 1.2 source; the 1.7 backend already contains the newer server-side OpenAI/Gemini integration, token validation, request limits and lockout behavior, so the newer 1.7 backend is retained rather than downgrading it to 1.2.
- Build foundation: flat-root clean-build structure, with no nested ZIP extraction.

## Build hardening
- Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21.
- Explicit Android SDK Platform 35, Build Tools 35.0.0 and platform-tools installation.
- SDK licenses accepted in a dedicated step; failure is not swallowed with `|| true`.
- `workflow_dispatch` only: the build starts manually, avoiding repeated builds on every repository commit.
- Pre-build source checks, clean Gradle build, APK existence check and artifact upload with failure if missing.
- App version 1.9 / versionCode 8.

## Static checks
The packaging process checks archive integrity, required file layout, workflow YAML syntax, Android XML parsing, web/Android asset parity, Node syntax, backend package metadata, Intro DNA records and build configuration.

## Not yet verified
- GitHub-hosted Android Gradle compilation and APK artifact creation.
- APK installation and runtime on a physical Android device.
- Live OpenAI/Gemini API calls after backend deployment and secret configuration.

**No source package can guarantee a successful remote build on every runner.** A release is considered build-verified only after GitHub Actions completes successfully and the APK artifact can be downloaded. Device/runtime and live backend testing are separate.
