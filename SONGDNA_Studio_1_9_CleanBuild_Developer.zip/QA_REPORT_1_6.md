# SONGDNA Studio 1.6 - QA Raporu

## Düzeltilenler
1. **Çift [Pre-Intro]:** `build()` içinde `lyrics` zaten etiketi içerirken `last.lyrics` tekrar `preTag+lyrics` olarak yazılıyordu. Tek kaynak hâline getirildi.
2. **Türkçe sızıntısı:** Style'daki vokal dili ifadesi ve Pre-Intro bölge adı Türkçe etiketten geliyordu; İngilizce karşılıklara bağlandı. Dil cümlesi "transition into lead vocals (<dil>)" biçimine getirildi.
3. **Token kilidi:** 8 hatalı denemeden sonra 5 dakika boyunca o IP'den gelen her istek (doğru token dahil) 429 alır. Önceki sürümde doğru token geçtiği için kilit gerçekte işlemiyordu.
4. Sürüm 1.6 / versionCode 5 / backend 1.6.0; README ve rapor güncellendi.

## Çalıştırılan testler (bu paket)
- Web ve backend JS sözdizimi, Manifest ve ikon XML, web = Android gömülü HTML.
- Tarayıcı: 252 dil x bölge x vokal kombinasyonunda Pre-Intro tam 1 kez, etikette ve Style'da Türkçe karakter/etiket yok; kullanıcı kendi [Pre-Intro] yazarsa tekrar eklenmez; Pre-Intro kapalıyken eklenmez; söz boşken LYRICS boş.
- 18 preset x 6 dil: Style her zaman <= 1000 karakter; EXCLUDE boş/dolu davranışı, kopyala/paylaş kilidi, BPM doğrulaması, arşive kayıt.
- Backend: 8 hatalı token sonrası doğru token dahil 429; 12 geçerli istekten sonra normal hız sınırı 429; anahtar yokken 503; bozuk JSON 400; büyük istek 413; sağlayıcı 400; token yoksa sunucu başlamaz; /health açık.

## Doğrulanmayanlar
- Gerçek APK derlemesi ve telefona kurulum.
- Android 15 (targetSdk 35) kenardan kenara çizimde başlığın durum çubuğu altında kalıp kalmadığı.
- Gerçek OpenAI/Gemini çağrısı (502/504 kodu okundu, çalıştırılmadı).
- HTTPS hosting, CORS/proxy ayarları (TRUST_PROXY).
- Telefonda pano, paylaş menüsü, klavye, ekran döndürme.

Bu paket kaynak ve yerel test düzeyinde tamamdır; yukarıdaki kabul testleri yapılmadan üretim onayı verilmiş sayılmaz.
