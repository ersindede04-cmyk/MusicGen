# GitHub'a yükleme — SONGDNA Studio 1.7

Bu ZIP'in içi doğrudan GitHub depo kökü olacak şekilde hazırlanmıştır.

## Önemli
- ZIP dosyasını GitHub'a tek dosya olarak yüklemeyin.
- ZIP'i telefonda/bilgisayarda çıkartın.
- Çıkan klasörün İÇİNDEKİ dosya ve klasörleri depo ana dizinine yükleyin.
- `.github` gizli klasörünü de mutlaka yükleyin. Dosya yöneticiniz gizli dosyaları saklıyorsa "Gizli dosyaları göster" seçeneğini açın.
- Depo ana dizininde `android-wrapper`, `backend`, `www`, `scripts`, `.github` klasörleri ve `README.md` görünmelidir.
- `.github/workflows/build-apk.yml` dosyasını elle yeniden yazmayın veya ikinci bir workflow oluşturmayın.

## APK alma
1. GitHub deposunu açın.
2. Actions sekmesine girin.
3. `Build Android APK` iş akışını seçin.
4. `Run workflow` düğmesine basın.
5. İşlem yeşil tik ile tamamlanınca çalıştırmayı açın.
6. `SONGDNA-Studio-1.7-debug` artifact dosyasını indirin.
7. İndirdiğiniz artifact ZIP'ini çıkartın; içindeki `app-debug.apk` dosyası kurulum dosyasıdır.

Kırmızı hata olursa `Build Android APK` çalıştırmasını açıp başarısız adımın tam hata metnini alın. Bu paketteki workflow kaynak ZIP'ini yeniden açmaya çalışmaz; doğrudan depo kökünden derler.
