# SONGDNA Studio 1.8 — Clean Build QA Report

## Verified locally
- Repository ZIP has a flat root layout; `.github/`, `android-wrapper/`, `backend/`, `www/`, and `scripts/` are top-level entries.
- Exactly one GitHub Actions workflow is included: `.github/workflows/build-apk.yml`.
- Workflow builds from repository root; it does not extract a nested ZIP.
- Workflow provisions Java 17, Gradle 8.9, Android SDK Platform 35 and Build Tools 35.0.0.
- Android app version is 1.8 (versionCode 7).
- Web UI and Android bundled HTML are byte-identical.
- Android XML resources parse.
- Backend package JSON parses and has a start script.
- Inline JavaScript and backend JavaScript pass Node syntax checks.
- Intro DNA presets 14–33 are present; previous regional automatic intro behavior remains.
- Workflow YAML parses successfully.

## Not yet verified
- GitHub-hosted Gradle/Android compilation.
- APK artifact download.
- APK installation and runtime on a physical Android device.
- Live OpenAI/Gemini backend connectivity and provider-key configuration.

A package is not considered a successful APK release until the GitHub Actions run is green and the APK artifact is downloadable. Device testing is a separate required step.
